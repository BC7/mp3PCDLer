import eyed3

def updateID3(metadata):
	# Test File location:
	# /home/brizzy/CodeWork/python/yt-dl[Front-End]/Free.mp3


	# fPath = str(input("Please enter File path: \n"))

	audiofile = eyed3.load(metadata["fileName"])
	audiofile.initTag()
	audiofile.tag.title = metadata["title"]
	audiofile.tag.artist = metadata["artist"]
	audiofile.tag.album = metadata["album"]
	audiofile.tag.genre = metadata["genre"]
	# audiofile.tag.title = u"Hollow"
	# audiofile.tag.track_num = 2

	audiofile.tag.save()
